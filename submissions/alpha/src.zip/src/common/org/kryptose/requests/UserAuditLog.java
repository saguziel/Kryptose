package org.kryptose.requests;

import java.io.Serializable;

/**
 * Created by jeff on 3/16/15.
 */
public class UserAuditLog implements Serializable {
    //TODO: implement
}
