package org.kryptose.client.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class KeyDerivatorTest {


	@Test
	public final void testGetAuthenticationKeyBytes() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetEncryptionKeyBytes() {
		fail("Not yet implemented"); // TODO
	}

}
